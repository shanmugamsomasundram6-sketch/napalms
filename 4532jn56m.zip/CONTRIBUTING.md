# Contributing to Nalam LMS

Thank you for helping improve Nalam LMS.

## Before you start

- Keep the project dependency-free unless a dependency is clearly justified.
- Preserve the English/Tamil learning experience when changing visible copy.
- Keep browser demo data local and clearly mark demo-only behavior.
- Do not commit `data/nalam-db.json`, credentials, API keys, or personal data.

## Suggested workflow

1. Create a focused branch for your change.
2. Make the smallest practical edit.
3. Check the page at desktop and mobile widths.
4. Test keyboard navigation and both language modes when UI text changes.
5. Check the API behavior when changing `server.js`.
6. Update the README when features, endpoints, or setup behavior change.
7. Open a pull request with a concise summary and testing notes.

## Pull requests

A good pull request should include:

- What changed and why
- Screenshots or a short screen recording for visual changes
- Notes about browser and API testing
- Any LocalStorage or database compatibility considerations
- Documentation updates, if needed

## Commit messages

Use short, descriptive messages such as:

- `Add certificate verification feedback`
- `Improve mobile dashboard layout`
- `Document attendance API`

## Reporting bugs

Use the bug report template and include reproduction steps, expected behavior, actual behavior, browser/device details, and screenshots where useful.

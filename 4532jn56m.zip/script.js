function readStoredJSON(key, fallback) {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch (error) {
    console.warn(`Could not read local data for ${key}.`, error);
    return fallback;
  }
}

function saveStoredJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    showToast('This browser could not save the demo data.');
    return false;
  }
}

const savedCustomCourses = readStoredJSON('nalamCustomCourses', []);
const courses = [
  { icon: '💻', title: ['Web Development', 'வலை உருவாக்கம்'], text: ['Build beautiful websites from scratch.', 'அழகான வலைத்தளங்களை உருவாக்குங்கள்.'], lessons: 18, level: ['Beginner', 'தொடக்கநிலை'], progress: 72, quiz: 86, certificate: true },
  { icon: '🐍', title: ['Python Essentials', 'Python அடிப்படைகள்'], text: ['Think, automate, and create with Python.', 'Python மூலம் சிந்தித்து, உருவாக்குங்கள்.'], lessons: 24, level: ['Beginner', 'தொடக்கநிலை'], progress: 58, quiz: 78, certificate: false },
  { icon: '📊', title: ['Data & AI Basics', 'தரவு மற்றும் AI அடிப்படைகள்'], text: ['Turn curious questions into insights.', 'கேள்விகளை பயனுள்ள தகவல்களாக மாற்றுங்கள்.'], lessons: 16, level: ['Intermediate', 'இடைநிலை'], progress: 41, quiz: 72, certificate: false },
  { icon: '🎨', title: ['UI & UX Design', 'UI மற்றும் UX வடிவமைப்பு'], text: ['Design clear, useful digital experiences.', 'தெளிவான டிஜிட்டல் அனுபவங்களை வடிவமைக்குங்கள்.'], lessons: 20, level: ['Beginner', 'தொடக்கநிலை'], progress: 35, quiz: 69, certificate: false },
  { icon: '🗄️', title: ['Backend Development', 'Backend உருவாக்கம்'], text: ['Create reliable APIs and server systems.', 'நம்பகமான API மற்றும் server அமைப்புகளை உருவாக்குங்கள்.'], lessons: 22, level: ['Intermediate', 'இடைநிலை'], progress: 24, quiz: 64, certificate: false },
  { icon: '🗣️', title: ['Tamil NLP', 'தமிழ் NLP'], text: ['Explore language technology with Tamil.', 'தமிழுடன் மொழி தொழில்நுட்பத்தை ஆராயுங்கள்.'], lessons: 14, level: ['Intermediate', 'இடைநிலை'], progress: 18, quiz: 61, certificate: false }
];

let language = localStorage.getItem('nalamLanguage') === 'ta' ? 'ta' : 'en';
const courseGrid = document.querySelector('#courseGrid');
const toast = document.querySelector('#toast');

function renderCourses() {
  courseGrid.innerHTML = courses.map((course, index) => `
    <article class="course">
      <div class="course-icon" aria-hidden="true">${course.icon}</div>
      <h3>${course.title[language === 'en' ? 0 : 1]}</h3>
      <p>${course.text[language === 'en' ? 0 : 1]}</p>
      <div class="course-meta"><span>${course.lessons} ${language === 'en' ? 'lessons' : 'பாடங்கள்'} · ${course.level[language === 'en' ? 0 : 1]}</span><button class="enroll" type="button" data-index="${index}">${language === 'en' ? 'Enroll →' : 'சேருங்கள் →'}</button></div>
    </article>`).join('');
}

function updateLanguage() {
  document.documentElement.lang = language === 'en' ? 'en' : 'ta';
  document.querySelectorAll('[data-en][data-ta]').forEach(element => {
    element.textContent = element.dataset[language === 'en' ? 'en' : 'ta'];
  });
  document.querySelector('#languageToggle').textContent = language === 'en' ? 'தமிழ்' : 'English';
  renderCourses();
}

const menuToggle = document.querySelector('#menuToggle');
const mainNavigation = document.querySelector('#mainNavigation');

menuToggle.addEventListener('click', () => {
  const isOpen = mainNavigation.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});

mainNavigation.addEventListener('click', event => {
  if (!event.target.closest('a')) return;
  mainNavigation.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Open navigation');
});

document.querySelector('#languageToggle').addEventListener('click', () => {
  language = language === 'en' ? 'ta' : 'en';
  localStorage.setItem('nalamLanguage', language);
  updateLanguage();
});

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 2600);
}

courseGrid.addEventListener('click', event => {
  const button = event.target.closest('.enroll');
  if (!button) return;
  const course = courses[button.dataset.index];
  localStorage.setItem('nalamActiveCourse', button.dataset.index);
  showLesson(course, Number(button.dataset.index));
  showToast(language === 'en' ? `Added ${course.title[0]} to your learning path.` : `${course.title[1]} உங்கள் கற்றல் பட்டியலில் சேர்க்கப்பட்டது.`);
});

const lessonTitle = document.querySelector('#lessonTitle');
const lessonProgress = document.querySelector('#lessonProgress');
const videoLearnerPath = document.querySelector('#videoLearnerPath');
const videoPathStatus = document.querySelector('#videoPathStatus');
let activeVideoStep = 0;
const lessonProgressBar = document.querySelector('#lessonProgressBar');
const videoPlaceholder = document.querySelector('#videoPlaceholder');
const certificateMessage = document.querySelector('#certificateMessage');

function updateVideoLearnerPath(step = activeVideoStep) {
  activeVideoStep = Math.max(0, Math.min(3, step));
  const labels = ['Start with the introduction', 'Build your foundation', 'Practise what you learned', 'Complete your assessment'];
  videoPathStatus.textContent = labels[activeVideoStep];
  videoLearnerPath.querySelectorAll('.video-path-step').forEach((item, index) => {
    item.classList.toggle('active', index === activeVideoStep);
    item.classList.toggle('complete', index < activeVideoStep);
    item.setAttribute('aria-current', index === activeVideoStep ? 'step' : 'false');
  });
}

function showLesson(course, index, shouldScroll = true) {
  lessonTitle.textContent = `${course.title[0]} — Introduction`;
  lessonProgress.textContent = `${course.progress}%`;
  lessonProgressBar.style.width = `${course.progress}%`;
  videoPlaceholder.innerHTML = `<span>▶</span><strong>${course.title[0]}</strong><small>Video lesson preview · ${course.lessons} lessons</small>`;
  localStorage.setItem('nalamActiveCourse', index);
  updateVideoLearnerPath(0);
  if (shouldScroll) document.querySelector('#learning').scrollIntoView({ behavior: 'smooth' });
}

videoLearnerPath.addEventListener('click', event => {
  const step = event.target.closest('.video-path-step');
  if (!step) return;
  const course = courses[Number(localStorage.getItem('nalamActiveCourse'))] || courses[0];
  const titles = ['Introduction', 'Essentials', 'Practice', 'Assessment'];
  const stepIndex = Number(step.dataset.step);
  lessonTitle.textContent = `${course.title[0]} — ${titles[stepIndex]}`;
  videoPlaceholder.innerHTML = `<span>▶</span><strong>${course.title[0]}: ${titles[stepIndex]}</strong><small>Video lesson ${stepIndex + 1} of 4 · Watch, practise, and continue</small>`;
  updateVideoLearnerPath(stepIndex);
  showToast(`Learner path: ${titles[stepIndex]}.`);
});

document.querySelector('#quizOptions').addEventListener('click', event => {
  const option = event.target.closest('button');
  if (!option) return;
  document.querySelectorAll('.quiz-options button').forEach(button => button.classList.remove('selected'));
  option.classList.add('selected');
  showToast(option.dataset.answer === 'correct' ? 'Correct answer! Quiz score saved: 100%.' : 'Not quite. Review the lesson and try again.');
  if (option.dataset.answer === 'correct') localStorage.setItem('nalamQuizScore', '100');
});

document.querySelector('#submitAssignment').addEventListener('click', () => {
  const assignment = document.querySelector('#assignmentText');
  if (!assignment.value.trim()) { showToast('Write a short assignment before submitting.'); return; }
  localStorage.setItem('nalamAssignment', assignment.value.trim());
  assignment.value = '';
  showToast('Assignment submitted and saved locally.');
});

const certificateModal = document.querySelector('#certificateModal');
const closeCertificate = document.querySelector('#closeCertificate');
const certificateStudentName = document.querySelector('#certificateStudentName');
const certificateCourseName = document.querySelector('#certificateCourseName');
const certificateDate = document.querySelector('#certificateDate');
const certificateId = document.querySelector('#certificateId');
const certificateAttendanceStatus = document.querySelector('#certificateAttendanceStatus');
const printCertificate = document.querySelector('#printCertificate');

function getCertificates() {
  return readStoredJSON('nalamCertificates', []);
}

function getCertificateForCourse(course, studentEmail) {
  return getCertificates().find(certificate => certificate.course === course.title[0] && certificate.email === studentEmail);
}

function generateCertificate(course, studentEmail, studentName) {
  const certificates = getCertificates();
  const existing = getCertificateForCourse(course, studentEmail);
  if (existing) return existing;
  const date = new Date();
  const certificate = {
    id: `NLMS-${date.getFullYear()}-${String(Date.now()).slice(-4).padStart(4, '0')}`,
    course: course.title[0],
    email: studentEmail,
    student: studentName,
    date: date.toISOString(),
    attendance: getAttendancePercentage()
  };
  certificates.push(certificate);
  saveStoredJSON('nalamCertificates', certificates);
  return certificate;
}

function openCertificate() {
  const student = localStorage.getItem('nalamStudent');
  if (!student) {
    showToast('Please log in as a student to view your certificate.');
    openAuth('login');
    return;
  }
  const activeIndex = Number(localStorage.getItem('nalamActiveCourse'));
  const course = courses[activeIndex] && courses[activeIndex].certificate ? courses[activeIndex] : courses.find(item => item.certificate);
  const studentName = localStorage.getItem('nalamStudentName') || student.split('@')[0];
  const certificate = generateCertificate(course, student, studentName.replace(/[._-]/g, ' '));
  const completedDate = new Date(certificate.date);
  certificateStudentName.textContent = certificate.student;
  certificateCourseName.textContent = certificate.course;
  certificateDate.textContent = `${String(completedDate.getDate()).padStart(2, '0')} - ${String(completedDate.getMonth() + 1).padStart(2, '0')} - ${completedDate.getFullYear()}`;
  certificateId.textContent = certificate.id;
  updateAttendance();
  certificateAttendanceStatus.textContent = `Verified · ${certificate.attendance}%`;
  certificateMessage.textContent = `Certificate generated for ${certificate.course}. ID: ${certificate.id}`;
  certificateStat.textContent = getCertificates().filter(item => item.email === student).length;
  certificateModal.hidden = false;
  document.body.style.overflow = 'hidden';
}

function closeCertificateModal() {
  certificateModal.hidden = true;
  document.body.style.overflow = '';
}

document.querySelector('#downloadCertificate').addEventListener('click', openCertificate);
closeCertificate.addEventListener('click', closeCertificateModal);
printCertificate.addEventListener('click', () => window.print());
certificateModal.addEventListener('click', event => {
  if (event.target === certificateModal) closeCertificateModal();
});

document.querySelector('#notes').addEventListener('click', event => {
  const button = event.target.closest('.note-link');
  if (!button) return;
  const messages = {
    html: ['HTML note saved: start with structure, then add meaning.', 'HTML குறிப்பு சேமிக்கப்பட்டது: முதலில் கட்டமைப்பை உருவாக்கி, பின்னர் பொருளைச் சேர்க்கவும்.'],
    javascript: ['JavaScript note saved: practice one small interaction at a time.', 'JavaScript குறிப்பு சேமிக்கப்பட்டது: ஒவ்வொரு முறையும் ஒரு சிறிய ஊடாடலைப் பயிற்சி செய்யுங்கள்.'],
    habits: ['Habit note saved: consistency beats long, irregular study sessions.', 'பழக்கக் குறிப்பு சேமிக்கப்பட்டது: நீண்ட, ஒழுங்கற்ற படிப்பை விட தொடர்ச்சி சிறந்தது.']
  };
  showToast(messages[button.dataset.note][language === 'en' ? 0 : 1]);
});

const teacherModal = document.querySelector('#teacherModal');
const teacherLoginButton = document.querySelector('#teacherLoginButton');
const closeTeacher = document.querySelector('#closeTeacher');
const teacherForm = document.querySelector('#teacherForm');
const teacherDashboard = document.querySelector('#teacherDashboard');
const teacherWelcome = document.querySelector('#teacherWelcome');
const teacherLogoutButton = document.querySelector('#teacherLogoutButton');
const videoForm = document.querySelector('#videoForm');
const noteForm = document.querySelector('#noteForm');
const videoCourse = document.querySelector('#videoCourse');
const contentNoteCourse = document.querySelector('#contentNoteCourse');
const uploadedContentList = document.querySelector('#uploadedContentList');

function populateTeacherCourses() {
  const options = courses.map((course, index) => `<option value="${index}">${course.title[0]}</option>`).join('');
  videoCourse.innerHTML = options;
  contentNoteCourse.innerHTML = options;
}

function renderUploadedContent() {
  const videos = readStoredJSON('nalamVideos', []);
  const notes = readStoredJSON('nalamNotes', []);
  const items = [
    ...videos.map(video => ({ type: 'Video', title: video.title, course: video.course, detail: video.file })),
    ...notes.map(note => ({ type: 'Note', title: note.title, course: note.course, detail: note.text }))
  ];
  uploadedContentList.innerHTML = items.length ? items.map(item => `
    <article class="content-item"><div><strong>${item.title}</strong><small>${item.course} · ${item.detail}</small></div><span class="content-type">${item.type}</span></article>`).join('') : '<p class="dashboard-welcome">No content uploaded yet.</p>';
}

savedCustomCourses.forEach(course => courses.push(course));

const ADMIN_EMAILS = ['admin@nalamlms.in', 'teacher@nalamlms.in'];
const adminStudentCount = document.querySelector('#adminStudentCount');
const adminCourseCount = document.querySelector('#adminCourseCount');
const adminAverageProgress = document.querySelector('#adminAverageProgress');
const adminCertificateCount = document.querySelector('#adminCertificateCount');
const adminStudentList = document.querySelector('#adminStudentList');
const announcementList = document.querySelector('#announcementList');

function renderAdminData() {
  const students = readStoredJSON('nalamStudents', []);
  const announcements = readStoredJSON('nalamAnnouncements', []);
  adminStudentCount.textContent = students.length;
  adminCourseCount.textContent = courses.length;
  adminAverageProgress.textContent = `${Math.round(courses.reduce((sum, course) => sum + course.progress, 0) / courses.length)}%`;
  adminCertificateCount.textContent = students.length ? courses.filter(course => course.certificate).length : 0;
  adminStudentList.innerHTML = students.length ? students.map(student => `<div class="admin-student"><span>👤 ${student.name || 'Student'}</span><small>${student.email}</small></div>`).join('') : '<p class="dashboard-welcome">No students registered yet.</p>';
  announcementList.innerHTML = announcements.length ? announcements.slice().reverse().map(item => `<div class="announcement-item"><span>${item.text}</span><small>${item.date}</small></div>`).join('') : '<p class="dashboard-welcome">No announcements yet.</p>';
}

function showTeacherDashboard(email) {
  populateTeacherCourses();
  renderAdminData();
  teacherWelcome.textContent = `Welcome, ${email}. Upload videos and publish notes for your students.`;
  renderUploadedContent();
  teacherDashboard.hidden = false;
}

function openTeacherLogin() {
  teacherModal.hidden = false;
  document.body.style.overflow = 'hidden';
  window.setTimeout(() => document.querySelector('#teacherEmail').focus(), 0);
}

function closeTeacherLogin() {
  teacherModal.hidden = true;
  document.body.style.overflow = '';
  teacherForm.reset();
}

teacherLoginButton.addEventListener('click', openTeacherLogin);
closeTeacher.addEventListener('click', closeTeacherLogin);
teacherModal.addEventListener('click', event => {
  if (event.target === teacherModal) closeTeacherLogin();
});
teacherForm.addEventListener('submit', event => {
  event.preventDefault();
  const email = document.querySelector('#teacherEmail').value.trim().toLowerCase();
  if (!ADMIN_EMAILS.includes(email)) {
    showToast('Access denied. Use an authorized admin or teacher email.');
    return;
  }
  localStorage.setItem('nalamTeacher', email);
  closeTeacherLogin();
  showTeacherDashboard(email);
  showToast(`Teacher login successful: ${email}`);
  teacherDashboard.scrollIntoView({ behavior: 'smooth' });
});

document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !teacherModal.hidden) closeTeacherLogin();
});

videoForm.addEventListener('submit', event => {
  event.preventDefault();
  const file = document.querySelector('#videoFile').files[0];
  const videos = readStoredJSON('nalamVideos', []);
  videos.push({ title: document.querySelector('#videoTitle').value.trim(), course: courses[videoCourse.value].title[0], file: file.name });
  saveStoredJSON('nalamVideos', videos);
  videoForm.reset();
  renderUploadedContent();
  showToast('Video uploaded successfully for this demo.');
});

document.querySelector('#courseForm').addEventListener('submit', event => {
  event.preventDefault();
  const newCourse = { icon: '📘', title: [document.querySelector('#adminCourseTitle').value.trim(), document.querySelector('#adminCourseTitle').value.trim()], text: [document.querySelector('#adminCourseDescription').value.trim(), document.querySelector('#adminCourseDescription').value.trim()], lessons: 0, level: ['Beginner', 'தொடக்கநிலை'], progress: 0, quiz: 0, certificate: false };
  courses.push(newCourse);
  const customCourses = JSON.parse(localStorage.getItem('nalamCustomCourses') || '[]');
  customCourses.push(newCourse);
  saveStoredJSON('nalamCustomCourses', customCourses);
  event.target.reset();
  renderCourses(); renderAdminData(); populateTeacherCourses();
  showToast('Course created successfully.');
});

document.querySelector('#announcementForm').addEventListener('submit', event => {
  event.preventDefault();
  const announcements = readStoredJSON('nalamAnnouncements', []);
  announcements.push({ text: document.querySelector('#announcementText').value.trim(), date: new Date().toLocaleDateString() });
  saveStoredJSON('nalamAnnouncements', announcements);
  event.target.reset(); renderAdminData(); showToast('Announcement published.');
});

noteForm.addEventListener('submit', event => {
  event.preventDefault();
  const notes = readStoredJSON('nalamNotes', []);
  notes.push({ title: document.querySelector('#contentNoteTitle').value.trim(), course: courses[contentNoteCourse.value].title[0], text: document.querySelector('#contentNoteText').value.trim() });
  saveStoredJSON('nalamNotes', notes);
  noteForm.reset();
  renderUploadedContent();
  showToast('Learning note published successfully.');
});

teacherLogoutButton.addEventListener('click', () => {
  localStorage.removeItem('nalamTeacher');
  teacherDashboard.hidden = true;
  showToast('Teacher has been logged out.');
});

const savedTeacher = localStorage.getItem('nalamTeacher');
if (savedTeacher && ADMIN_EMAILS.includes(savedTeacher)) showTeacherDashboard(savedTeacher);
else if (savedTeacher) localStorage.removeItem('nalamTeacher');

const savedCourseIndex = Number(localStorage.getItem('nalamActiveCourse'));
if (Number.isInteger(savedCourseIndex) && courses[savedCourseIndex]) showLesson(courses[savedCourseIndex], savedCourseIndex);

const authModal = document.querySelector('#authModal');
const loginButton = document.querySelector('#loginButton');
const signupButton = document.querySelector('#signupButton');
const closeAuth = document.querySelector('#closeAuth');
const loginTab = document.querySelector('#loginTab');
const signupTab = document.querySelector('#signupTab');
const authForm = document.querySelector('#authForm');
const authTitle = document.querySelector('#authTitle');
const authSubtitle = document.querySelector('#authSubtitle');
const authSubmit = document.querySelector('#authSubmit');
const nameFields = document.querySelectorAll('.name-field');
const dashboard = document.querySelector('#dashboard');
const dashboardWelcome = document.querySelector('#dashboardWelcome');
const dashboardCourses = document.querySelector('#dashboardCourses');
const profileName = document.querySelector('#profileName');
const profileEmail = document.querySelector('#profileEmail');
const profileAvatar = document.querySelector('#profileAvatar');
const notificationBanner = document.querySelector('#notificationBanner');
const learningPathTitle = document.querySelector('#learningPathTitle');
const learningPathSummary = document.querySelector('#learningPathSummary');
const learningPathTrack = document.querySelector('#learningPathTrack');
const continuePathButton = document.querySelector('#continuePathButton');
const logoutButton = document.querySelector('#logoutButton');
const enrolledStat = document.querySelector('#enrolledStat');
const progressStat = document.querySelector('#progressStat');
const quizStat = document.querySelector('#quizStat');
const certificateStat = document.querySelector('#certificateStat');
const attendanceButton = document.querySelector('#attendanceButton');
const attendanceMessage = document.querySelector('#attendanceMessage');
const attendancePanel = document.querySelector('.attendance-panel');
const certificateAttendance = document.querySelector('#certificateAttendance');
const attendanceStat = document.querySelector('#attendanceStat');
let authMode = 'login';

function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getAttendancePercentage() {
  const attendance = readStoredJSON('nalamAttendance', {});
  const dates = Object.keys(attendance);
  if (!dates.length) return 0;

  const firstDate = new Date(`${dates.sort()[0]}T00:00:00`);
  const today = new Date();
  firstDate.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);

  const elapsedDays = Math.max(1, Math.floor((today - firstDate) / 86400000) + 1);
  const presentDays = dates.filter(date => attendance[date] === true).length;
  return Math.min(100, Math.round((presentDays / elapsedDays) * 100));
}

function updateAttendance() {
  const attendance = readStoredJSON('nalamAttendance', {});
  const verifiedToday = attendance[getTodayKey()] === true;
  const percentage = getAttendancePercentage();
  attendancePanel.classList.toggle('verified', verifiedToday);
  attendanceButton.textContent = verifiedToday ? 'Attendance verified ✓' : 'Check in today';
  attendanceButton.disabled = verifiedToday;
  attendanceMessage.textContent = verifiedToday
    ? `Your attendance has been verified for today. Attendance: ${percentage}%.`
    : `Check in today to verify your attendance. Attendance: ${percentage}%.`;
  attendanceStat.textContent = `${percentage}%`;
  certificateAttendance.textContent = verifiedToday ? 'Attendance verified' : 'Attendance pending';
  certificateAttendanceStatus.textContent = verifiedToday ? `Verified · ${percentage}%` : `Check in required · ${percentage}%`;
}

attendanceButton.addEventListener('click', () => {
  const attendance = readStoredJSON('nalamAttendance', {});
  attendance[getTodayKey()] = true;
  saveStoredJSON('nalamAttendance', attendance);
  updateAttendance();
  showToast('Attendance verified successfully for today.');
});

function renderLearningPath() {
  const activeIndex = Number(localStorage.getItem('nalamActiveCourse'));
  const activeCourse = courses[activeIndex] || courses[0];
  const progress = activeCourse.progress;
  const completed = progress >= 100 ? 4 : progress >= 75 ? 3 : progress >= 40 ? 2 : progress > 0 ? 1 : 0;
  const milestones = [
    ['Choose your course', 'Start with a clear goal'],
    ['Learn the essentials', 'Build your foundation'],
    ['Practise your skills', 'Apply what you learned'],
    ['Complete & celebrate', 'Earn your certificate']
  ];

  learningPathTitle.textContent = activeCourse.title[language === 'en' ? 0 : 1];
  learningPathSummary.textContent = `${progress}% complete · ${activeCourse.lessons} lessons · Keep going towards your next milestone.`;
  learningPathTrack.innerHTML = milestones.map((milestone, index) => `
    <div class="path-step ${index < completed ? 'completed' : ''} ${index === completed && completed < milestones.length ? 'current' : ''}">
      <span class="path-step-number">${index < completed ? '✓' : index + 1}</span>
      <strong>${milestone[0]}</strong>
      <small>${milestone[1]}</small>
    </div>`).join('');
}

function renderDashboard(email) {
  const name = localStorage.getItem('nalamStudentName') || email.split('@')[0];
  dashboardWelcome.textContent = `Welcome back, ${name}. Continue your learning journey.`;
  profileName.textContent = name;
  profileEmail.textContent = email;
  profileAvatar.textContent = name.charAt(0).toUpperCase();
  const announcements = readStoredJSON('nalamAnnouncements', []);
  notificationBanner.hidden = !announcements.length;
  notificationBanner.textContent = announcements.length ? `🔔 ${announcements[announcements.length - 1].text}` : '';
  enrolledStat.textContent = courses.length;
  progressStat.textContent = `${Math.round(courses.reduce((total, course) => total + course.progress, 0) / courses.length)}%`;
  quizStat.textContent = `${Math.max(...courses.map(course => course.quiz))}%`;
  certificateStat.textContent = getCertificates().filter(certificate => certificate.email === email).length;
  attendanceStat.textContent = `${getAttendancePercentage()}%`;
  dashboardCourses.innerHTML = courses.map(course => `
    <article class="dashboard-course">
      <div class="dashboard-course-heading"><h3>${course.icon} ${course.title[0]}</h3><span class="dashboard-course-score">Quiz: ${course.quiz}%</span></div>
      <div class="dashboard-progress"><i style="width: ${course.progress}%"></i></div>
      <small>${course.progress}% complete · ${course.certificate ? 'Certificate earned 🏆' : `${course.lessons} lessons`}</small>
    </article>`).join('');
  renderLearningPath();
  dashboard.hidden = false;
}

function loadStudent() {
  const student = localStorage.getItem('nalamStudent');
  if (student) {
    renderDashboard(student);
    updateAttendance();
  }
}


function setAuthMode(mode) {
  authMode = mode;
  const signup = mode === 'signup';
  loginTab.classList.toggle('active', !signup);
  signupTab.classList.toggle('active', signup);
  loginTab.setAttribute('aria-selected', String(!signup));
  signupTab.setAttribute('aria-selected', String(signup));
  authTitle.textContent = signup ? 'Create your account' : 'Welcome back';
  authSubtitle.textContent = signup ? 'Start learning without limits.' : 'Continue your learning journey.';
  authSubmit.textContent = signup ? 'Create account' : 'Log in';
  nameFields.forEach(field => {
    field.hidden = !signup;
    field.required = signup && field.tagName === 'INPUT';
  });
  document.querySelector('#authPassword').autocomplete = signup ? 'new-password' : 'current-password';
}

function openAuth(mode) {
  setAuthMode(mode);
  authModal.hidden = false;
  document.body.style.overflow = 'hidden';
  window.setTimeout(() => document.querySelector('#authEmail').focus(), 0);
}

function closeAuthModal() {
  authModal.hidden = true;
  document.body.style.overflow = '';
  authForm.reset();
}

loginButton.addEventListener('click', () => openAuth('login'));
signupButton.addEventListener('click', () => openAuth('signup'));
continuePathButton.addEventListener('click', () => {
  const activeIndex = Number(localStorage.getItem('nalamActiveCourse'));
  const course = courses[activeIndex] || courses[0];
  showLesson(course, courses.indexOf(course));
});
logoutButton.addEventListener('click', () => {
  localStorage.removeItem('nalamStudent');
  dashboard.hidden = true;
  showToast('You have been logged out.');
});
loginTab.addEventListener('click', () => setAuthMode('login'));
signupTab.addEventListener('click', () => setAuthMode('signup'));
closeAuth.addEventListener('click', closeAuthModal);
authModal.addEventListener('click', event => {
  if (event.target === authModal) closeAuthModal();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !authModal.hidden) closeAuthModal();
  if (event.key === 'Escape' && !certificateModal.hidden) closeCertificateModal();
});
authForm.addEventListener('submit', event => {
  event.preventDefault();
  const email = document.querySelector('#authEmail').value.trim();
  localStorage.setItem('nalamStudent', email);
  const students = readStoredJSON('nalamStudents', []);
  const name = document.querySelector('#authName').value.trim();
  const existingStudent = students.find(student => student.email === email);
  if (!existingStudent) students.push({ email, name: name || email.split('@')[0], joined: new Date().toLocaleDateString() });
  saveStoredJSON('nalamStudents', students);
  if (name) localStorage.setItem('nalamStudentName', name);
  renderDashboard(email);
  toast.textContent = authMode === 'signup'
    ? `Welcome to Nalam LMS, ${email}!`
    : `You are logged in as ${email}.`;
  closeAuthModal();
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 2600);
  document.querySelector('#dashboard').scrollIntoView({ behavior: 'smooth' });
});

document.querySelector('#themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  const dark = document.body.classList.contains('dark-mode');
  localStorage.setItem('nalamDarkMode', String(dark));
  document.querySelector('#themeToggle').textContent = dark ? '☀️' : '🌙';
});
if (localStorage.getItem('nalamDarkMode') === 'true') {
  document.body.classList.add('dark-mode');
  document.querySelector('#themeToggle').textContent = '☀️';
}

document.querySelector('#profileButton').addEventListener('click', () => {
  const name = window.prompt('Enter your display name:', localStorage.getItem('nalamStudentName') || '');
  if (!name || !localStorage.getItem('nalamStudent')) return;
  localStorage.setItem('nalamStudentName', name.trim());
  renderDashboard(localStorage.getItem('nalamStudent'));
  showToast('Profile updated successfully.');
});

document.querySelector('#verifyForm').addEventListener('submit', event => {
  event.preventDefault();
  const id = document.querySelector('#verifyId').value.trim().toUpperCase();
  const result = document.querySelector('#verificationResult');
  const certificate = getCertificates().find(item => item.id === id);
  const valid = Boolean(certificate);
  result.textContent = valid
    ? `✓ Certificate ${id} is valid: ${certificate.student} completed ${certificate.course}.`
    : 'Certificate not found. Generate a certificate first, then verify its ID.';
  result.style.color = valid ? '#16834b' : '#c2410c';
});

updateLanguage();
loadStudent();
# Nalam LMS

> A bilingual English/Tamil learning management system demo for practical, accessible online learning.

Nalam LMS is a responsive web project built with semantic HTML, modern CSS, and vanilla JavaScript. It includes a browser-only demo experience plus an optional dependency-free Node.js API for a more complete local project.

## Highlights

- English/Tamil language toggle
- Responsive mobile-first layout
- Light and dark themes
- Student registration and login demo
- Student dashboard with learning paths and progress
- Course cards, video lesson flow, quizzes, and assignments
- Attendance check-in and progress tracking
- Certificate generation, printing, and ID verification
- Teacher/admin dashboard
- Course and announcement management
- LocalStorage persistence for the browser demo
- Optional JSON-backed Node.js API with password hashing
- Deterministic local course-outline generator without external services

## Project structure

```text
nalam-lms/
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   └── workflows/
│       └── validate.yml
├── data/
│   └── .gitkeep
├── .env.example
├── .gitignore
├── CONTRIBUTING.md
├── LICENSE
├── README.md
├── SECURITY.md
├── index.html
├── package.json
├── script.js
├── server.js
└── styles.css
```

## Quick start

### Browser-only demo

Open `index.html` in a modern browser. The frontend works without a build step or third-party JavaScript packages.

The browser demo stores its data in LocalStorage. This includes demo accounts, selected courses, attendance, assignments, announcements, uploaded video metadata, notes, certificates, language preference, and theme preference.

### Optional local API

The repository also includes `server.js`, a dependency-free Node.js server. It serves the frontend and exposes JSON endpoints for authentication, courses, progress, attendance, announcements, certificates, and admin analytics.

The project expects Node.js 18 or newer and includes a `start` package script. The default server address is `http://localhost:3000`. Set `PORT` or `HOST` through environment variables when needed. See `.env.example` for the supported configuration values.

The first server startup creates `data/nalam-db.json` from the seed data. That file is intentionally ignored by Git because it contains local runtime data.

## Demo accounts

### Browser teacher portal

Use either authorized email in the Teacher Login dialog:

```text
admin@nalamlms.in
teacher@nalamlms.in
```

The browser-only teacher demo validates the email address for access. It does not provide real authentication.

### API administrator

The seeded API administrator is:

```text
Email:    admin@nalamlms.in
Password: Admin@12345
```

Set `ADMIN_PASSWORD` before the first API startup to replace the seed password. Change it for any shared or deployed environment.

## API overview

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register` | Register a student |
| POST | `/api/auth/login` | Log in and receive a bearer token |
| POST | `/api/auth/logout` | End the current session |
| GET | `/api/me` | Read the authenticated user |
| GET | `/api/courses` | List published courses |
| POST | `/api/courses` | Create a course as an admin |
| POST | `/api/ai/generate-course` | Generate a local course outline as an admin |
| GET | `/api/dashboard` | Read the student dashboard |
| POST | `/api/progress` | Save course progress |
| POST | `/api/attendance` | Check in for attendance |
| POST | `/api/announcements` | Publish an announcement as an admin |
| POST | `/api/certificates` | Issue a certificate for the current student |
| GET | `/api/certificates/verify?id=...` | Verify a certificate ID |
| GET | `/api/admin/analytics` | Read admin metrics |

The current frontend remains intentionally browser-first. A production integration should replace the relevant LocalStorage calls with authenticated API requests and add a proper session strategy.

## Data and security

This is an educational demo, not a production authentication system. The API hashes passwords with Node.js `scrypt`, but sessions are kept in server memory and the JSON database is local. Do not use the seeded credentials, LocalStorage authentication, or the development server for real user data.

For production, add HTTPS, secure and persistent sessions, rate limiting, validation, CSRF protection where applicable, a real database, access-controlled file storage, audit logging, and a managed secrets strategy.

## Accessibility and browser support

The interface uses semantic sections, labels, keyboard-focus styles, dialog attributes, status announcements, responsive controls, and reduced-motion preferences. Use a current version of Chrome, Edge, Firefox, or Safari for the best experience.

## Contributing

Contributions are welcome. Read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request. Please use the issue templates for bug reports and feature ideas.

## Security

Please do not publish credentials, API keys, database files, or personal information in issues or pull requests. See [SECURITY.md](SECURITY.md) for responsible disclosure guidance.

## License

This project is released under the MIT License. See [LICENSE](LICENSE).

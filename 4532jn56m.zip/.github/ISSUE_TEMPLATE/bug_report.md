---
name: Bug report
about: Report a reproducible problem
---

## Summary

Describe the problem briefly.

## Steps to reproduce

1.
2.
3.

## Expected behavior

What did you expect to happen?

## Actual behavior

What happened instead?

## Environment

- Browser and version:
- Device or screen size:
- Browser demo or API:
- Relevant LocalStorage/API state:

## Screenshots or logs

Add screenshots or sanitized logs if helpful. Do not include passwords, tokens, or personal data.

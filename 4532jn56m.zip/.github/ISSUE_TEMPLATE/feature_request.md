---
name: Feature request
about: Suggest an improvement
---

## Problem

What user problem would this solve?

## Proposed solution

Describe the feature or change.

## Alternatives considered

What other approaches did you consider?

## Additional context

Include mockups, examples, or related issues if available.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'nalam-db.json');
const sessions = new Map();

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, expected] = String(stored).split(':');
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
}

function createId(prefix) {
  return `${prefix}_${crypto.randomBytes(8).toString('hex')}`;
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function seedDatabase() {
  return {
    users: [{
      id: 'user_admin',
      name: 'Nalam Administrator',
      email: 'admin@nalamlms.in',
      passwordHash: hashPassword(process.env.ADMIN_PASSWORD || 'Admin@12345'),
      role: 'admin',
      createdAt: new Date().toISOString()
    }],
    courses: [
      { id: 'course_web', title: 'Web Development', description: 'Build beautiful websites from scratch.', level: 'Beginner', lessons: 18, progress: 0, published: true, createdAt: new Date().toISOString() },
      { id: 'course_python', title: 'Python Essentials', description: 'Think, automate, and create with Python.', level: 'Beginner', lessons: 24, progress: 0, published: true, createdAt: new Date().toISOString() }
    ],
    lessons: [],
    quizzes: [],
    assignments: [],
    progress: [],
    attendance: [],
    announcements: [],
    certificates: []
  };
}

function loadDb() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const initial = seedDatabase();
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    throw new Error('The database file is invalid. Remove data/nalam-db.json and restart.');
  }
}

let db = loadDb();
function saveDb() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function send(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': process.env.ALLOW_ORIGIN || '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
  });
  res.end(JSON.stringify(payload));
}

function publicUser(user) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1_000_000) req.destroy(new Error('Request body is too large.'));
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try { resolve(JSON.parse(body)); } catch { reject(new Error('Request body must be valid JSON.')); }
    });
    req.on('error', reject);
  });
}

function getToken(req) {
  const header = req.headers.authorization || '';
  return header.startsWith('Bearer ') ? header.slice(7) : '';
}

function currentUser(req) {
  const userId = sessions.get(getToken(req));
  return db.users.find(user => user.id === userId) || null;
}

function requireUser(req, res, roles = []) {
  const user = currentUser(req);
  if (!user) { send(res, 401, { error: 'Login required.' }); return null; }
  if (roles.length && !roles.includes(user.role)) { send(res, 403, { error: 'You do not have permission for this action.' }); return null; }
  return user;
}

function findCourse(id) { return db.courses.find(course => course.id === id); }
function findUser(id) { return db.users.find(user => user.id === id); }

function generateCourse(input) {
  const title = String(input.title || 'AI Generated Course').trim();
  const topic = String(input.topic || title).trim();
  const level = String(input.level || 'Beginner').trim();
  const lessonTitles = [
    `Introduction to ${topic}`,
    `${topic} fundamentals`,
    `Practising ${topic}`,
    `Building a ${topic} project`,
    `${topic} assessment and next steps`
  ];
  return {
    id: createId('course'), title, description: `An AI-generated ${level.toLowerCase()} course about ${topic}.`, level,
    lessons: lessonTitles.length, progress: 0, published: false, aiGenerated: true, createdAt: new Date().toISOString(),
    lessonDrafts: lessonTitles.map((lessonTitle, index) => ({
      title: lessonTitle,
      content: `Learn the key ideas of ${topic} in lesson ${index + 1}. Practise with a small, practical activity.`,
      quiz: { question: `What is an important part of ${lessonTitle}?`, options: ['Practice and understanding', 'Skipping every exercise', 'Ignoring feedback'], answer: 0 }
    }))
  };
}

async function handleApi(req, res, url) {
  const parts = url.pathname.split('/').filter(Boolean);
  const route = parts.slice(1); // remove api
  const method = req.method;
  const body = ['POST', 'PUT', 'PATCH'].includes(method) ? await readBody(req) : {};

  if (method === 'POST' && route[0] === 'auth' && route[1] === 'register') {
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!email || password.length < 6) return send(res, 400, { error: 'Email and a password with at least 6 characters are required.' });
    if (db.users.some(user => user.email === email)) return send(res, 409, { error: 'An account with this email already exists.' });
    const user = { id: createId('user'), name: String(body.name || email.split('@')[0]).trim(), email, passwordHash: hashPassword(password), role: 'student', createdAt: new Date().toISOString() };
    db.users.push(user); saveDb();
    const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, user.id);
    return send(res, 201, { token, user: publicUser(user) });
  }

  if (method === 'POST' && route[0] === 'auth' && route[1] === 'login') {
    const email = String(body.email || '').trim().toLowerCase();
    const user = db.users.find(item => item.email === email);
    if (!user || !verifyPassword(String(body.password || ''), user.passwordHash)) return send(res, 401, { error: 'Invalid email or password.' });
    const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, user.id);
    return send(res, 200, { token, user: publicUser(user) });
  }

  if (method === 'POST' && route[0] === 'auth' && route[1] === 'logout') { sessions.delete(getToken(req)); return send(res, 200, { message: 'Logged out.' }); }
  if (method === 'GET' && route[0] === 'me') { const user = requireUser(req, res); if (user) send(res, 200, { user: publicUser(user) }); return; }

  if (method === 'GET' && route[0] === 'courses') return send(res, 200, { courses: db.courses.filter(course => course.published || currentUser(req)?.role === 'admin') });

  if (method === 'POST' && route[0] === 'courses' && route.length === 1) {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    const course = { id: createId('course'), title: String(body.title || '').trim(), description: String(body.description || '').trim(), level: String(body.level || 'Beginner'), lessons: 0, progress: 0, published: Boolean(body.published), createdAt: new Date().toISOString() };
    if (!course.title || !course.description) return send(res, 400, { error: 'Course title and description are required.' });
    db.courses.push(course); saveDb(); return send(res, 201, { course });
  }

  if (method === 'POST' && route[0] === 'ai' && route[1] === 'generate-course') {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    return send(res, 200, { course: generateCourse(body), mode: 'local-template-ai' });
  }

  if (route[0] === 'courses' && route[1] && route[2] === 'publish' && method === 'PUT') {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    const course = findCourse(route[1]); if (!course) return send(res, 404, { error: 'Course not found.' });
    course.published = Boolean(body.published); saveDb(); return send(res, 200, { course });
  }

  if (route[0] === 'courses' && route[1] && route[2] === 'lessons' && method === 'POST') {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    if (!findCourse(route[1])) return send(res, 404, { error: 'Course not found.' });
    const lesson = { id: createId('lesson'), courseId: route[1], title: String(body.title || '').trim(), videoUrl: String(body.videoUrl || ''), content: String(body.content || ''), createdAt: new Date().toISOString() };
    if (!lesson.title) return send(res, 400, { error: 'Lesson title is required.' });
    db.lessons.push(lesson); saveDb(); return send(res, 201, { lesson });
  }

  if (route[0] === 'courses' && route[1] && route[2] === 'quizzes' && method === 'POST') {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    const quiz = { id: createId('quiz'), courseId: route[1], question: String(body.question || '').trim(), options: Array.isArray(body.options) ? body.options : [], answer: Number(body.answer) || 0, createdAt: new Date().toISOString() };
    if (!quiz.question || quiz.options.length < 2) return send(res, 400, { error: 'A quiz question and at least two options are required.' });
    db.quizzes.push(quiz); saveDb(); return send(res, 201, { quiz });
  }

  if (method === 'GET' && route[0] === 'dashboard') {
    const user = requireUser(req, res); if (!user) return;
    const ownProgress = db.progress.filter(item => item.userId === user.id);
    const ownAttendance = db.attendance.filter(item => item.userId === user.id);
    return send(res, 200, { user: publicUser(user), courses: db.courses.filter(course => course.published), progress: ownProgress, attendance: ownAttendance, announcements: db.announcements, certificates: db.certificates.filter(item => item.userId === user.id) });
  }

  if (method === 'POST' && route[0] === 'progress') {
    const user = requireUser(req, res); if (!user) return;
    const item = db.progress.find(progress => progress.userId === user.id && progress.courseId === body.courseId);
    if (item) item.percent = Math.max(0, Math.min(100, Number(body.percent) || 0));
    else db.progress.push({ id: createId('progress'), userId: user.id, courseId: body.courseId, percent: Math.max(0, Math.min(100, Number(body.percent) || 0)), updatedAt: new Date().toISOString() });
    saveDb(); return send(res, 200, { message: 'Progress saved.' });
  }

  if (method === 'POST' && route[0] === 'attendance') {
    const user = requireUser(req, res); if (!user) return;
    const date = String(body.date || today());
    if (!db.attendance.some(item => item.userId === user.id && item.date === date)) db.attendance.push({ id: createId('attendance'), userId: user.id, date, present: true });
    saveDb(); return send(res, 200, { percentage: attendancePercentage(user.id) });
  }

  if (method === 'POST' && route[0] === 'announcements') {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    const announcement = { id: createId('announcement'), text: String(body.text || '').trim(), date: new Date().toISOString() };
    if (!announcement.text) return send(res, 400, { error: 'Announcement text is required.' });
    db.announcements.push(announcement); saveDb(); return send(res, 201, { announcement });
  }

  if (method === 'POST' && route[0] === 'certificates') {
    const user = requireUser(req, res); if (!user) return;
    const certificate = { id: `NLMS-${new Date().getFullYear()}-${String(db.certificates.length + 1).padStart(4, '0')}`, userId: user.id, courseId: body.courseId, issuedAt: new Date().toISOString(), attendancePercentage: attendancePercentage(user.id) };
    db.certificates.push(certificate); saveDb(); return send(res, 201, { certificate });
  }

  if (method === 'GET' && route[0] === 'certificates' && route[1] === 'verify') {
    const certificate = db.certificates.find(item => item.id === String(url.searchParams.get('id') || '').toUpperCase());
    return certificate ? send(res, 200, { valid: true, certificate }) : send(res, 404, { valid: false, error: 'Certificate not found.' });
  }

  if (method === 'GET' && route[0] === 'admin' && route[1] === 'analytics') {
    const user = requireUser(req, res, ['admin']); if (!user) return;
    const students = db.users.filter(item => item.role === 'student');
    const average = db.progress.length ? Math.round(db.progress.reduce((sum, item) => sum + item.percent, 0) / db.progress.length) : 0;
    return send(res, 200, { students: students.map(publicUser), metrics: { students: students.length, courses: db.courses.length, lessons: db.lessons.length, quizzes: db.quizzes.length, certificates: db.certificates.length, averageProgress: average } });
  }

  send(res, 404, { error: 'API route not found.' });
}

function attendancePercentage(userId) {
  const records = db.attendance.filter(item => item.userId === userId && item.present);
  if (!records.length) return 0;
  const first = new Date(records.map(item => item.date).sort()[0]);
  const days = Math.max(1, Math.floor((new Date(today()) - first) / 86400000) + 1);
  return Math.min(100, Math.round((records.length / days) * 100));
}

function serveStatic(req, res, url) {
  const requested = url.pathname === '/' ? '/index.html' : url.pathname;
  const file = path.normalize(path.join(ROOT, requested));
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) return send(res, 404, { error: 'File not found.' });
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8' };
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (error) {
    console.error(error);
    send(res, 500, { error: 'Internal server error.' });
  }
});

server.listen(PORT, HOST, () => console.log(`Nalam LMS backend listening on port ${PORT}`));

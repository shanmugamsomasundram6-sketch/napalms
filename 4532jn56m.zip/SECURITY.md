# Security policy

## Scope

Nalam LMS is primarily a learning/demo project. The browser authentication and LocalStorage data are not suitable for real accounts or sensitive information.

## Reporting a vulnerability

Please do not open a public issue for a security vulnerability. Contact the project maintainers privately through the repository's security contact or GitHub private vulnerability reporting if it is enabled.

Include:

- A clear description of the issue
- Reproduction steps or a proof of concept
- The affected file or endpoint
- Potential impact
- Any suggested mitigation

Please allow maintainers reasonable time to investigate before public disclosure.

## Safe development practices

- Never commit `.env` files, passwords, API keys, or `data/nalam-db.json`.
- Replace the seeded administrator password before using the API outside a local demo.
- Do not put real student information in LocalStorage or the JSON database.
- Use HTTPS, persistent secure sessions, rate limiting, validation, and a real database in production.
